#ifndef __WATCHPOINT_H__
#define __WATCHPOINT_H__

#include "common.h"

typedef struct watchpoint {
  int NO;
  struct watchpoint *next;
  char expression[50];
  /* TODO: Add more members if necessary */
  int  val;
  int newval;

} WP;

 void init_wp_pool();
 WP * new_wp();
void free_wp(WP* wp);
void print_wp();
  void print_free();
void wp_write(char *args);
void exec_watch(int* is_batch_mode);
#endif
