#include "nemu.h"

/* We use the POSIX regex functions to process regular expressions.
 * Type 'man regex' for more information about POSIX regex functions.
 */
#include <sys/types.h>
#include <regex.h>
#include <stdlib.h>
enum {
  TK_NOTYPE = 256, TK_EQ,TK_INT_10,TK_INT_16,TK_UE,LOG_AND,TK_NEGA,TK_DERE,TK_REG

  /* TODO: Add more token types */

};

static struct rule {
  char *regex;
  int token_type;
} rules[] = {

  /* TODO: Add more rules.
   * Pay attention to the precedence level of different rules.
   */

  {" +", TK_NOTYPE},    // spaces
  {"\\+", '+'},         // plus
  {"==", TK_EQ},         // equal
  {"!=",TK_UE},         //unequal
  {"&&",LOG_AND},       //logical and
  {"-",'-'},          //subtraction
  {"\\*",'*'},           //multiplication
  {"/",'/'} ,             //division
  {"\\$[Ee][a-dA-DSsiI][xXiIpP]",TK_REG},           //register
  {"\\(",'('},          //left parenthesis
  {"\\)",')'},           //right parenthesis
  {"([1-9]+[0-9]*)",TK_INT_10},//integer_10
  {"0[xX][0-9a-fA-F]+",TK_INT_16}//integer_16
};

#define NR_REGEX (sizeof(rules) / sizeof(rules[0]) )

static regex_t re[NR_REGEX];

/* Rules are used for many times.
 * Therefore we compile them only once before any usage.
 */
void init_regex() {
  int i;
  char error_msg[128];
  int ret;

  for (i = 0; i < NR_REGEX; i ++) {
    ret = regcomp(&re[i], rules[i].regex, REG_EXTENDED);
    if (ret != 0) {
      regerror(ret, &re[i], error_msg, 128);
      panic("regex compilation failed: %s\n%s", error_msg, rules[i].regex);
    }
  }
}

typedef struct token {
  int type;
  char str[32];
} Token;

Token tokens[32];
int nr_token;

static bool make_token(char *e) {
  /*for(int i=0;i<32;++i){
    printf("before");
    printf("%d:",tokens[i].type);
    for(int j=0;j<32;++j){
      printf("%c",tokens[i].str[j]);
    }
    printf("\n");
  }*/
  int position = 0;
  int i;
  regmatch_t pmatch;

  nr_token = 0;

  while (e[position] != '\0') {
    /* Try all rules one by one. */
    for (i = 0; i < NR_REGEX; i ++) {
      if (regexec(&re[i], e + position, 1, &pmatch, 0) == 0 && pmatch.rm_so == 0) {
        char *substr_start = e + position;
        int substr_len = pmatch.rm_eo;

        Log("match rules[%d] = \"%s\" at position %d with len %d: %.*s",
            i, rules[i].regex, position, substr_len, substr_len, substr_start);
        position += substr_len;

        /* TODO: Now a new token is recognized with rules[i]. Add codes
         * to record the token in the array `tokens'. For certain types
         * of tokens, some extra actions should be performed.
         */
        //printf("%d %d",rules[i].token_type,TK_INT_10);
        switch (rules[i].token_type) {
          case TK_NOTYPE:tokens[nr_token].type=TK_NOTYPE;++nr_token;break;
          case '+':tokens[nr_token].type='+';++nr_token;break;	
	  case TK_EQ:tokens[nr_token].type=TK_EQ;++nr_token;break;	
	  case '-':tokens[nr_token].type='-';++nr_token;break;
	  case '*':tokens[nr_token].type='*';++nr_token;break;
	  case '/':tokens[nr_token].type='/';++nr_token;break;
 	  case TK_REG:tokens[nr_token].type=TK_REG;for(int j=0;j<substr_len;++j)tokens[nr_token].str[j]=substr_start[j];++nr_token;break;
	  case '(':tokens[nr_token].type='(';++nr_token;break;
	  case ')':tokens[nr_token].type=')';++nr_token;break;
          case TK_INT_10:tokens[nr_token].type=TK_INT_10;for(int j=0;j<substr_len;++j)tokens[nr_token].str[j]=substr_start[j];++nr_token;break;
          case TK_INT_16:tokens[nr_token].type=TK_INT_16;for(int j=0;j<substr_len;++j)tokens[nr_token].str[j]=substr_start[j];++nr_token;break;
          default: TODO();
        }

        break;
      }
    }

    if (i == NR_REGEX) {
      printf("no match at position %d\n%s\n%*.s^\n", position, e, position, "");
      return false;
    }
  }
  /*for(int i=0;i<nr_token;++i){
    printf("%d:",tokens[i].type);
    for(int j=0;j<strlen(tokens[i].str);++j){
      printf("%c",tokens[i].str[j]);
    }
    printf("\n");
  }*/
  //for(int i=0;i<nr_token;++i){
  //printf("%d\n",tokens[i].type);}
  return true;
}
bool check_parentheses(uint32_t m,uint32_t n,bool *flag){
   char stack[32];
   int len=0;
   int x=m;
   for(int i=m;i<=n;++i){
      if(tokens[i].type=='('){
         stack[len++]='(';
         if(len==1)x=i;
      }
      else if(tokens[i].type==')'){
        if(--len<0){
          *flag=false;
          return false;
          }
         else stack[len]=' ';
      }
   }
   if(stack[0]=='('){
     *flag=false;
     return false;
   }
   if(tokens[m].type=='('&&tokens[n].type==')'&&x==m)return true;
   else return false;
}
uint32_t eval(uint32_t m,uint32_t n){
   //printf("m:%d,n=%d\n",m,n);
   bool flagx=true;
   if(m>n){
      printf("bad expression \n");
      return 0;
   }
   else if(m==n){
      if(tokens[n].type==TK_INT_16){
        int ret;
        sscanf(tokens[n].str,"%x",&ret);
        return ret;
      }
      else if(tokens[n].type==TK_INT_10){
        return atoi(tokens[n].str);
      }
      else if(tokens[n].type==TK_REG){
        if((tokens[n].str[1]=='e'&&tokens[n].str[2]=='a'&&tokens[n].str[3]=='x')||(tokens[n].str[1]=='E'&&tokens[n].str[2]=='A'&&tokens[n].str[3]=='X'))return cpu.eax;
        else if((tokens[n].str[1]=='e'&&tokens[n].str[2]=='b'&&tokens[n].str[3]=='x')||(tokens[n].str[1]=='E'&&tokens[n].str[2]=='B'&&tokens[n].str[3]=='X'))return cpu.ebx;
        else if((tokens[n].str[1]=='e'&&tokens[n].str[2]=='c'&&tokens[n].str[3]=='x')||(tokens[n].str[1]=='E'&&tokens[n].str[2]=='C'&&tokens[n].str[3]=='X'))return cpu.ecx;
        else if((tokens[n].str[1]=='e'&&tokens[n].str[2]=='d'&&tokens[n].str[3]=='x')||(tokens[n].str[1]=='E'&&tokens[n].str[2]=='D'&&tokens[n].str[3]=='X'))return cpu.edx;
        else if((tokens[n].str[1]=='e'&&tokens[n].str[2]=='s'&&tokens[n].str[3]=='p')||(tokens[n].str[1]=='E'&&tokens[n].str[2]=='S'&&tokens[n].str[3]=='P'))return cpu.esp;
        else if((tokens[n].str[1]=='e'&&tokens[n].str[2]=='b'&&tokens[n].str[3]=='p')||(tokens[n].str[1]=='E'&&tokens[n].str[2]=='B'&&tokens[n].str[3]=='P'))return cpu.ebp; 
        else if((tokens[n].str[1]=='e'&&tokens[n].str[2]=='s'&&tokens[n].str[3]=='i')||(tokens[n].str[1]=='E'&&tokens[n].str[2]=='S'&&tokens[n].str[3]=='I'))return cpu.esi;   
        else if((tokens[n].str[1]=='e'&&tokens[n].str[2]=='d'&&tokens[n].str[3]=='i')||(tokens[n].str[1]=='E'&&tokens[n].str[2]=='D'&&tokens[n].str[3]=='I'))return cpu.edi; 
        else if((tokens[n].str[1]=='e'&&tokens[n].str[2]=='i'&&tokens[n].str[3]=='p')||(tokens[n].str[1]=='E'&&tokens[n].str[2]=='I'&&tokens[n].str[3]=='P'))return cpu.eip;  
      }
   }
   else if(check_parentheses(m,n,&flagx)==true){
        return eval(m+1,n-1);
   }
   else if(flagx==false){
        printf("the expression ");
        printf("is error\n");
   }
   else{
        int pos=m;
        int op_type=' ';
        int flag=100;
        //for(int i=m;i<=n;++i){printf("%d ",tokens[i].type);
        //}
        int flag2=0;
        for(int i=m;i<=n;++i){
           //printf("%d:%d\n",i,tokens[i].type);
           switch(tokens[i].type){
             case '+':if(!flag2&&flag>2){pos=i;flag=3;op_type='+';;}break;
             case '-':if(!flag2&&flag>2){pos=i;flag=3;op_type='-';}break;
             case '*':if(!flag2&&flag>3){pos=i;flag=4;op_type='*';};break;
             case '/':if(!flag2&&flag>3){pos=i;flag=4;op_type='/';};break;
             case '(':flag2++;break;
             case ')':flag2--;break;
             case LOG_AND:if(!flag2&&flag>0){pos=i;flag=1;op_type=LOG_AND;}break;
             case TK_UE:if(!flag2&&flag>1){pos=i;flag=2;op_type=TK_UE;}break;
             case TK_EQ:if(!flag2&&flag>1){pos=i;flag=2;op_type=TK_EQ;}break;
             case TK_NEGA:if(!flag2&&flag>4){pos=i;flag=5;op_type=TK_NEGA;}break;
             case TK_DERE:if(!flag2&&flag>4){pos=i;flag=5;op_type=TK_DERE;}break;
             default:break;
           }
        }
        switch(op_type){
          case '+':return eval(m,pos-1)+eval(pos+1,n);
          case '-':return eval(m,pos-1)-eval(pos+1,n);
          case '*':return eval(m,pos-1)*eval(pos+1,n);
          case '/':return eval(m,pos-1)/eval(pos+1,n);
          case LOG_AND:return eval(m,pos-1)&&eval(pos+1,n);
          case TK_UE:return eval(m,pos-1)!=eval(pos+1,n);
          case TK_EQ:return eval(m,pos-1)==eval(pos+1,n);
          case TK_NEGA:return -eval(pos+1,n);
          case TK_DERE:return paddr_read(eval(pos+1,n), 4);
          default:assert(0);
        }
        
   }
   return 0;
}
uint32_t expr(char *e, bool *success) {
  if (!make_token(e)) {
    *success = false;
    return 0;
  }
  //delete space
  int len=0;
  for(int i=0;i+len<nr_token;++i){
    while(tokens[i+len].type==TK_NOTYPE)len++;
    tokens[i].type=tokens[i+len].type;
    for(int j=0;j<strlen(tokens[i+len].str);++j){
      tokens[i].str[j]=tokens[i+len].str[j];
    }
  }
  nr_token-=len;
  for(int i=0;i<nr_token;++i){
    if(tokens[i].type=='-'&&(i==0||tokens[i-1].type=='('||tokens[i-1].type=='*'||tokens[i-1].type=='-'||tokens[i-1].type=='+'||tokens[i-1].type=='/'||tokens[i-1].type=='*')){
      tokens[i].type=TK_NEGA;
    }
    if(tokens[i].type=='*'&&(i==0||tokens[i-1].type=='('||tokens[i-1].type=='*'||tokens[i-1].type=='-'||tokens[i-1].type=='+'||tokens[i-1].type=='/'||tokens[i-1].type=='*')){
      tokens[i].type=TK_DERE;
    }
  }
  //clear tokens
  uint32_t ret=eval(0,nr_token-1);
  for(int i=0;i<32;++i){
    tokens[i].type=0;
    for(int j=0;j<32;++j){
      tokens[i].str[j]=0;
    }
  }
  //nr_token=0;
  return ret;
  /* TODO: Insert codes to evaluate the expression. */
  TODO();

  return 0;
}
