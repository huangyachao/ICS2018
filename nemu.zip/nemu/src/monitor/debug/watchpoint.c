#include "monitor/watchpoint.h"
#include "monitor/expr.h"
#include "monitor/monitor.h"
#define NR_WP 32

static WP wp_pool[NR_WP];
static WP *head, *free_;

 void init_wp_pool() {
  int i;
  for (i = 0; i < NR_WP; i ++) {
    wp_pool[i].val=0;
    for(int j=0;j<50;++j){
      wp_pool[i].expression[j]='\0';
    }
    wp_pool[i].NO = i;
    wp_pool[i].next = &wp_pool[i + 1];
  }
  wp_pool[NR_WP - 1].next = NULL;

  head = NULL;
  free_ = wp_pool;
}
 WP * new_wp(){
  if(free_==NULL)assert(0);
  else{
 
     WP* ret=free_;
     free_->val=0;
     free_=free_->next;
    return ret;
  }
}
 void free_wp(WP* wp){
  WP*h=head;
  WP*f=head;
  if(head->NO==wp->NO)head=head->next;
  else{
    while(h->next&&h->next->NO!=wp->NO){
      h=h->next;
    }
    if(h->next==NULL){printf("error NO\n");return;}
    f=h->next;
    h->next=h->next->next;
  }
  f->next=NULL;
  f->val=0;
  for(int j=0;j<50;++j){
     f->expression[j]='\0';
    }
  if(free_==NULL)free_=wp;
  else{
    WP*p=free_;
    while(p->next){
      p=p->next;
    }
    p->next=f;
  }
}
  void print_wp(){
    WP*h=head;
    if(head==NULL)printf("no watchpoint\n");
    else {
      printf("wp:\n");
      while(h){
        printf("NO=%d\texpr=\"%s\"\tvalue=%d\t\n",h->NO,h->expression,h->val);
        h=h->next;
      }
      
    }
  }
  void print_free(){
    WP*f=free_;
    if(f==NULL)printf("no freepoint\n");
    else{
      printf("free:\n");
      while(f){
        printf("NO%d:%s\n",f->NO,f->expression);
        f=f->next;
      }
    }
}
void wp_write(char *args){
  WP* p=new_wp();
  p->next=NULL;
  bool x=true;
  p->val=expr(args,&x);
  for(int i=0;i<strlen(args);++i){
   p->expression[i]=args[i];
  }
  if(head==NULL)head=p;
  else{
    WP* h=head;
    while(h->next){
      h=h->next;
    }
    h->next=p;
  }
}
void exec_watch(int* is_batch_mode){
  WP*h=head;
  bool x=true;
  while(h){
    int temp=expr(h->expression,&x);
    if(temp!=h->newval){
      *is_batch_mode=NEMU_STOP;
      h->val=h->newval;
      h->newval=temp;
      printf("stoped watchpoint:");
      printf("NO=%d\texpr=\"%s\"\told val=%d\tnew val=%d\n",h->NO,h->expression,h->val,h->newval);
      //free_wp(h);
     }
     h=h->next;

  }
}
/* TODO: Implement the functionality of watchpoint */


