#include "monitor/monitor.h"
#include "monitor/expr.h"
#include "monitor/watchpoint.h"
#include "nemu.h"
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
void cpu_exec(uint64_t);
/* We use the `readline' library to provide more flexibility to read from stdin. */
char* rl_gets() {
  static char *line_read = NULL;

  if (line_read) {
    free(line_read);
    line_read = NULL;
  }

  line_read = readline("(nemu) ");

  if (line_read && *line_read) {
    add_history(line_read);
  }

  return line_read;
}

static int cmd_c(char *args) {
  cpu_exec(-1);
  return 0;
}

static int cmd_q(char *args) {
  return -1;
}

static int cmd_si(char *args) {
  char *arg = strtok(NULL, " ");
  if(arg == NULL){
     cpu_exec(1);
     return 0;
  }
  else {
     int num=atoi(arg);
     cpu_exec(num);
     return 0;
  }

}
static int cmd_p(char *args){
  //char *arg = strtok(NULL, " ");
  if(args==NULL){
    printf("no args\n");
    return 0;}
  bool x=true;
  int val=expr(args,&x);
  if(val)printf("the value of expression:%d\n",val);
  return 0;
}
static int cmd_info(char *args){
  //char *arg = strtok(NULL, " ");
  if(args == NULL){
     printf("no args\n");
  }
  else if(strlen(args)!=1){
     printf("unkown args '%s'\n",args);
  }
  else if(args[0]=='r'){
    printf("EAX:%x\tAX:%04x\tAH:%02x\tAL:%02x\n",cpu.eax,cpu.eax&0xFFFF,(cpu.eax&0xFF00)>>8,cpu.eax&0xFF);
    printf("EBX:%x\tBX:%04x\tBH:%02x\tBL:%02x\n",cpu.ebx,cpu.ebx&0xFFFF,(cpu.ebx&0xFF00)>>8,cpu.ebx&0xFF);
    printf("ECX:%x\tCX:%04x\tCH:%02x\tCL:%02x\n",cpu.ecx,cpu.ecx&0xFFFF,(cpu.ecx&0xFF00)>>8,cpu.ecx&0xFF);
    printf("EDX:%x\tDX:%04x\tDH:%02x\tDL:%02x\n",cpu.edx,cpu.edx&0xFFFF,(cpu.edx&0xFF00)>>8,cpu.edx&0xFF);
    printf("ESP:%x\tSP:%04x\n",cpu.esp,cpu.esp&0xFFFF);
    printf("EBP:%x\tBP:%04x\n",cpu.ebp,cpu.ebp&0xFFFF);
    printf("ESI:%x\tSI:%04x\n",cpu.esi,cpu.esi&0xFFFF);
    printf("EDI:%x\tDI:%04x\n",cpu.edi,cpu.edi&0xFFFF);
    printf("EIP:%x\n",cpu.esp);
  }
  else if(args[0]=='w'){
    print_wp();
    //print_free();
  }
  else
     printf("unkown args '%s'\n",args);
  return 0;
}
static int cmd_help(char *args);
static int cmd_x(char *args){
  char *arg1 = strtok(NULL, " ");
  char *arg2 = strtok(NULL, " ");
  if(arg1 == NULL||arg2 == NULL){
     printf("false args\n");
     return 0;
  }
  int n=atoi(arg1);
  bool x=true;
  int addr=expr(arg2,&x);
  for(int i=0;i<n;++i){
    printf("%x:%x\n",addr,paddr_read(addr,4));
    addr+=4;
  }
  return 0;
}
static int cmd_w(char *args){
  wp_write(args);
  return 0;
}
/*static int cmd_w(char *args){
  WP* p=new_wp();
  p->next=NULL;
  bool x=true;
  p->val=expr(args,&x);
  for(int i=0;i<strlen(args);++i){
   p->expression[i]=args[i];
  }
  if(head==NULL)head=p;
  else{
    while(head->next){
      head=head->next;
    }
    head->next=p;
  }
  return 0;
}*/
static int cmd_d(char *args){
  int n=atoi(args);
  struct watchpoint wp1={
    .NO=0,
    .val=0,
    .expression=" ",
    .next=NULL,
  };
  wp1.NO=n;
  WP*p=&wp1;
  free_wp(p);
  return 0;
}
static struct {
  char *name;
  char *description;
  int (*handler) (char *);
} cmd_table [] = {
  { "help", "Display informations about all supported commands", cmd_help },
  { "c", "Continue the execution of the program", cmd_c },
  { "q", "Exit NEMU", cmd_q },
  {"si","Perform N steps",cmd_si},
  {"info","Print program status",cmd_info},
  {"p","Get expression value",cmd_p},
  {"x","Scan memory",cmd_x},
  {"w","Set watchpoint",cmd_w},
  {"d","Delete watchpoint",cmd_d}


  /* TODO: Add more commands */

};

#define NR_CMD (sizeof(cmd_table) / sizeof(cmd_table[0]))

static int cmd_help(char *args) {
  /* extract the first argument */
  char *arg = strtok(NULL, " ");
  int i;

  if (arg == NULL) {
    /* no argument given */
    for (i = 0; i < NR_CMD; i ++) {
      printf("%s - %s\n", cmd_table[i].name, cmd_table[i].description);
    }
  }
  else {
    for (i = 0; i < NR_CMD; i ++) {
      if (strcmp(arg, cmd_table[i].name) == 0) {
        printf("%s - %s\n", cmd_table[i].name, cmd_table[i].description);
        return 0;
      }
    }
    printf("Unknown command '%s'\n", arg);
  }
  return 0;
}

void ui_mainloop(int is_batch_mode) {
  /*WP*h=head;
  bool x=true;
  while(h){
    if(expr(h->expression,&x)!=h->val){
      is_batch_mode=NEMU_STOP;
      printf("stoped watchpoint:");
        printf("%s\n",h->expression);
      h=h->next;
     }
  }*/
  //printf("watch\n");
  if (is_batch_mode) {
    cmd_c(NULL);
    return;
  }
  for (char *str; (str = rl_gets()) != NULL; ) {
    char *str_end = str + strlen(str);

    /* extract the first token as the command */
    char *cmd = strtok(str, " ");
    if (cmd == NULL) { continue; }

    /* treat the remaining string as the arguments,
     * which may need further parsing
     */
    char *args = cmd + strlen(cmd) + 1;
    if (args >= str_end) {
      args = NULL;
    }

#ifdef HAS_IOE
    extern void sdl_clear_event_queue(void);
    sdl_clear_event_queue();
#endif

    int i;
    for (i = 0; i < NR_CMD; i ++) {
      if (strcmp(cmd, cmd_table[i].name) == 0) {
        if (cmd_table[i].handler(args) < 0) { return; }
        break;
      }
    }

    if (i == NR_CMD) { printf("Unknown command '%s'\n", cmd); }
  }
}
