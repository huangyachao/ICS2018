#ifndef __DIFF_TEST_H__
#define __DIFF_TEST_H__

#define DIFFTEST_REG_SIZE (sizeof(uint32_t) * 9) // GRPs + EIP

#endif
